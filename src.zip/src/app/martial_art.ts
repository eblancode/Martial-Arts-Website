export class Martial_art {
    id: number;
    name: string;
    description: string;
    history: string;
    type: string;
    specialty: string;
    agresivity: string;
    equipment: string;
    competition_type: string;
    adoption_rate: number;
    floor_type: string;
    origin_country: string;
    foundation_year: number;
}